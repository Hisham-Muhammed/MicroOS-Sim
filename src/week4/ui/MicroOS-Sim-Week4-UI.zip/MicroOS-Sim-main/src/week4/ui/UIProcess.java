package week4.ui;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

/**
 * Week 4 UI process for MicroOS-Sim.
 * Communicates with the Core process only through two POSIX named FIFOs.
 */
public class UIProcess {
    private static final Path UI_TO_CORE =
            Paths.get("/tmp/microos_ui_to_core.fifo");
    private static final Path CORE_TO_UI =
            Paths.get("/tmp/microos_core_to_ui.fifo");

    public static void main(String[] args) {
        System.out.println("MicroOS-Sim Week 4 UI Process");
        System.out.println("UI -> Core: " + UI_TO_CORE);
        System.out.println("Core -> UI: " + CORE_TO_UI);

        if (!Files.exists(UI_TO_CORE) || !Files.exists(CORE_TO_UI)) {
            System.err.println("FIFO not found. Create both FIFOs first:");
            System.err.println("mkfifo " + UI_TO_CORE);
            System.err.println("mkfifo " + CORE_TO_UI);
            return;
        }

        System.out.println("Waiting for Core process to connect...");
        try (
            // Opening a FIFO writer waits until the Core opens its reader.
            BufferedWriter toCore = Files.newBufferedWriter(
                    UI_TO_CORE, StandardCharsets.UTF_8);
            // Opening a FIFO reader waits until the Core opens its writer.
            BufferedReader fromCore = Files.newBufferedReader(
                    CORE_TO_UI, StandardCharsets.UTF_8);
            Scanner scanner = new Scanner(System.in)
        ) {
            System.out.println("Connected. Commands: LOAD, STEP, RUN, RESET, SHOW, EXIT");
            boolean running = true;

            while (running) {
                System.out.print("ui> ");
                if (!scanner.hasNextLine()) {
                    break;
                }

                String command = scanner.nextLine().trim().toUpperCase();
                if (command.isEmpty()) {
                    continue;
                }

                if (!isValid(command)) {
                    System.out.println("Unknown command. Use LOAD, STEP, RUN, RESET, SHOW, EXIT.");
                    continue;
                }

                // Send one command per line. The Core reads the newline-delimited message.
                toCore.write(command);
                toCore.newLine();
                toCore.flush();

                // The Core must send one newline-terminated response for each command.
                String response = fromCore.readLine();
                if (response == null) {
                    System.err.println("Core closed the response FIFO. Disconnecting.");
                    break;
                }

                System.out.println("Core: " + response);
                if (command.equals("EXIT")) {
                    running = false;
                }
            }
        } catch (IOException e) {
            System.err.println("FIFO communication error: " + e.getMessage());
            System.err.println("Check that the Core process is running and both FIFOs exist.");
        }

        System.out.println("UI Process stopped.");
    }

    private static boolean isValid(String command) {
        return command.equals("LOAD")
                || command.equals("STEP")
                || command.equals("RUN")
                || command.equals("RESET")
                || command.equals("SHOW")
                || command.equals("EXIT");
    }
}
