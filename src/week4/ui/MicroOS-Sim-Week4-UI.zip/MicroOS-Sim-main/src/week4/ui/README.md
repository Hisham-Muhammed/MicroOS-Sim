# Week 4 UI Process (POSIX FIFO)

## Files
- `UIProcess.java`: standalone UI process. It does not import or call Week 1–3 simulator classes.

## FIFO paths (fixed)
- UI to Core: `/tmp/microos_ui_to_core.fifo`
- Core to UI: `/tmp/microos_core_to_ui.fifo`

## Message protocol
The UI writes one command per line (`LOAD`, `STEP`, `RUN`, `RESET`, `SHOW`, `EXIT`) to the UI-to-Core FIFO and flushes it. For every command, the Core must write exactly one newline-terminated status/response line to the Core-to-UI FIFO. `EXIT` should receive a response before the Core shuts down its side.

The Core should open the UI-to-Core FIFO for reading and then the Core-to-UI FIFO for writing. The UI opens its writer first and reader second. FIFO opens are blocking; start the Core before the UI. Both processes must agree on the one-command/one-response protocol.

## Compile (from project root)
```sh
mkdir -p out
javac -d out src/week4/ui/UIProcess.java
```

## Run
In a Linux/macOS/WSL terminal, create the FIFOs once:
```sh
mkfifo /tmp/microos_ui_to_core.fifo
mkfifo /tmp/microos_core_to_ui.fifo
```
Start the integrated Core process in one terminal, then:
```sh
java -cp out week4.ui.UIProcess
```
The Core process is not included in this UI implementation.

## Independent UI/FIFO smoke test
This test uses a temporary shell process as a protocol peer, not a simulator/Core implementation. Run it on Linux or WSL. First compile as above. In terminal 1:
```sh
rm -f /tmp/microos_ui_to_core.fifo /tmp/microos_core_to_ui.fifo
mkfifo /tmp/microos_ui_to_core.fifo /tmp/microos_core_to_ui.fifo
while IFS= read -r command < /tmp/microos_ui_to_core.fifo; do
  printf 'TEST-PEER received: %s\\n' "$command"
  printf 'TEST-PEER response to %s\\n' "$command" > /tmp/microos_core_to_ui.fifo
  [ "$command" = EXIT ] && break
done
```
Then in terminal 2 run `java -cp out week4.ui.UIProcess` and enter `SHOW`, then `EXIT`.
Expected UI output includes `Core: TEST-PEER response to SHOW` and `Core: TEST-PEER response to EXIT`. Terminal 1 prints the received commands. This verifies both FIFO directions and the line protocol, but final integration must also be tested against the real Core.

## IPC architecture and measurements
`UI Process -> UI-to-Core FIFO -> Core Process -> CPU/Memory/Stack/Queue -> Logging Process`.
The Core sends its response to the UI through the Core-to-UI FIFO. The UI has no direct dependency on CPU, Memory, Stack, Queue, Simulator, or Logging classes.

For comparison, measure the same fixed command workload in (a) the existing standalone simulator and (b) the integrated multi-process system. Record workload/iteration count, wall-clock elapsed time, and per-command latency. Estimate IPC overhead by comparing matched workloads, while noting that process startup, file loading, and logging can also affect the difference. Measure CPU and memory with OS tools such as `/usr/bin/time -v` on Linux; report the process scope and whether startup is included. Repeat trials and report mean/median rather than relying on one run.

Suggested test cases:
1. `SHOW`: UI sends command; Core returns current status.
2. `STEP`: UI sends command; Core returns step result.
3. `RUN`: UI sends command; Core returns run result.
4. `RESET`: UI sends command; Core returns reset status.
5. `LOAD`: UI sends command; Core returns load status (Core defines program-loading details).
6. `EXIT`: Core acknowledges, then closes cleanly.
7. Unknown input: UI rejects it locally and does not send it.
8. Missing FIFO/Core: UI reports setup/connection or I/O error rather than crashing.
9. Real integration: repeat command cases against the actual Core process and verify its state changes.

Note: POSIX FIFO support is required. On Windows, use WSL or a Linux environment. FIFO paths and the protocol are fixed for team integration.
